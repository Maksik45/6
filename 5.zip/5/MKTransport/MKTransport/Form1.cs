﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MKTransport
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a;

            a = Convert.ToInt32(textBox1.Text);

            if (radioButton1.Checked)
            {

                a = (a * 150);
                textBox2.Text = Convert.ToString(a);

            }
            else
            if (radioButton2.Checked)
            {
                a = (a * 250);
                textBox2.Text = Convert.ToString(a);
            }
            else
            if (radioButton3.Checked)
            {
                a = (a * 350);
                textBox2.Text = Convert.ToString(a);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
