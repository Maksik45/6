﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MKSteklo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a;
            int b;
            a = Convert.ToInt32(textBox1.Text);
            b = Convert.ToInt32(textBox2.Text);

            if
                {
                comboBox1.SelectedIndex == 0
              (a < 800)
            { int sum = 10600 + 1000; }
            else { int sum = 10600 + 1500; }
                if (a < 1300)
                { int sum = 14600 + 1000; }
                else { int sum = 14600 + 1500; }
            }

    }
    }
}
